import '../../assets/styles/btnPublicar.css'

function btnPublicar() {
    return (
            <button className='contenedorPublicar'>PUBLICAR</button>
    );
}

export default btnPublicar;