import '../../assets/styles/btnCancelar.css'

function btnCancelar() {
    return (
            <button className='contenedorCancelar'>CANCELAR</button>
    );
}

export default btnCancelar;