import '../../assets/styles/FiltrarPorPrecioLandingPage.css'

function FiltrarPorPrecioLandingPage() {
    return (

        <div class="container">
            <p class="texto">FILTRAR POR PRECIO - FILTRAR POR PRECIO - FILTRAR POR PRECIO -
                FILTRAR POR PRECIO - FILTRAR POR PRECIO - FILTRAR POR PRECIO - FILTRAR POR PRECIO</p>
        </div>

    );
}

export default FiltrarPorPrecioLandingPage;