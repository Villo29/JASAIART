import HeaderLandingPage from "../componentes/atomos/HeaderLadingPage";
import ProductoVista from "../componentes/moleculas/Producto";
import FooterPerfilU from "../componentes/atomos/FooterPerfilU";



function Producto() {
    return (
        <>
            <HeaderLandingPage></HeaderLandingPage>
            <ProductoVista></ProductoVista>

        </>
    );
}

export default Producto;