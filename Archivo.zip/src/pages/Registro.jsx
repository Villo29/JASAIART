import RegistroL from "../componentes/moleculas/Register";


function Registro() {

    return (
        <RegistroL></RegistroL>
    );
}

export default Registro;