import Formcontacto from "../componentes/moleculas/Formcontacto";
import Header from "../componentes/atomos/header";

function Contacto() {
    return ( 
        <>
        <Header/>
        <Formcontacto/>
        </>
     );
}

export default Contacto;