import Login from "../componentes/moleculas/LoginF";


function Login() {
    return (
        <Login></Login>
    );
}

export default Login;